﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;

namespace ChoreTracker
{
    class AddChild
    {

        public static string newChildFirstname;
        public static string newChildLastname;
        public static string newChildUsername;
        public static string parentId;

        public static void childCreated()
        {
            Console.WriteLine("New Child: " + AddChild.newChildFirstname + AddChild.newChildLastname + "\nUsername: " + AddChild.newChildUsername + "\nLinked To Parent ID: " + Login.userId + "was created!");
        }
        public static void getDetails()
        {
            
           


            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine(MainTitle.Title());
            Console.ResetColor();
            UserDetails.DetailsBanner();

            Console.WriteLine("Enter First Name: ");
            newChildFirstname = Console.ReadLine();
            Console.Clear();

            Console.ForegroundColor = ConsoleColor.Green;   
            Console.WriteLine(MainTitle.Title());
            Console.ResetColor();
            UserDetails.DetailsBanner();
            Console.WriteLine("Enter Last Name: ");
            newChildLastname = Console.ReadLine();
            Console.Clear();

            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine(MainTitle.Title());
            Console.ResetColor();
            UserDetails.DetailsBanner();
            Console.WriteLine("Enter Child Username: ");
            newChildUsername = Console.ReadLine();
            Console.Clear();

           
            
        }



        public static void newChild()
        {
            string cs = @"server=172.16.71.1;userid=davidduenas;password=pwd123;database=ChoreDatabase;port=8889";

            using (MySqlConnection conn1 = new MySqlConnection(cs))
            {
                using (MySqlCommand cmd = new MySqlCommand())
                {
                    cmd.Connection = conn1;
                    conn1.Open();
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.CommandText = @"INSERT INTO ChoreDatabase.child
	                                  (childFirstname, childLastname, childUserName, parentId)
                                      VALUES
	                                  (@newChildFirstname, @newChildLastname, @newChildUsername, @parentId)";

                    cmd.Parameters.AddWithValue("@newChildFirstName", AddChild.newChildFirstname);
                    cmd.Parameters.AddWithValue("@newChildLastName", AddChild.newChildLastname);
                    cmd.Parameters.AddWithValue("@newChildUserName", AddChild.newChildUsername);
                    cmd.Parameters.AddWithValue("@parentId", Login.userId);

                    
                        try
                        {
                            
                            cmd.ExecuteNonQuery();
                        }
                        catch (MySqlException ex)
                        {
                            Console.WriteLine("Error: {0}", ex.ToString());
                        }


                    conn1.Close();
                }
            }

            AddChild.childCreated();
        }
    }
}
