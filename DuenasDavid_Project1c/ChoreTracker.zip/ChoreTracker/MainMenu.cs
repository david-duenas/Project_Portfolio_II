﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChoreTracker
{
    class MainMenu
    {
        public static void Menu()
        {
            Console.WriteLine("Welcome to Chore Tracker, " + Login.firstName+"!");
            Console.WriteLine("-------------------------");
            Console.WriteLine("\n\n\n");

            Console.WriteLine("Select an option from the menu below:");
            Console.WriteLine("1 | Track a Chore");
            Console.WriteLine("2 | View Chore Log");
            Console.WriteLine("3 | Add a Child");
            Console.WriteLine("4 | Log Out");
            Console.WriteLine("5 | Exit");
        }
    }
}
