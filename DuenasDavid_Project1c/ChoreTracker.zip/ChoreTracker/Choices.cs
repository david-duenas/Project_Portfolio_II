﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChoreTracker
{
    class Choices
    {
        public static void PickChoice()
        {
            string input = Console.ReadLine();
            int inputNum;
            int.TryParse(input, out inputNum);


            if (inputNum == 1)
            {
                Console.Clear();
                Console.WriteLine(MainTitle.Title());
                MainMenu.Menu();
            }
            else if (inputNum == 2)
            {
                Console.Clear();
                Console.WriteLine(MainTitle.Title());
                ChoreLog.ViewLog();
            }
            else if (inputNum == 3)
            {

            }
            else if (inputNum == 4)
            {

            }
        }
    }
}
