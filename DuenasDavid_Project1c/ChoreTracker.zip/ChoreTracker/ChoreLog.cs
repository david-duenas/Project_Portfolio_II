﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;

namespace ChoreTracker
{
    class ChoreLog
    {
        //ChoreLog Strings
        public static string _id;
        public static string _choreCategory;
        public static string _choreDescription;
        public static string _childFirstname;
        public static string _username;

        public static void ViewLog()
        {
            //Show what the user entered
            string cs = @"server=172.16.71.1;userid=davidduenas;password=pwd123;database=ChoreDatabase;port=8889";

            using (MySqlConnection conn1 = new MySqlConnection(cs))
            {
                using (MySqlCommand cmd = new MySqlCommand())
                {
                    cmd.Connection = conn1;
                    conn1.Open();
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.CommandText = @"SELECT
	                            choreLog.id,
	                            choreLog.choreCategory,
	                            choreLog.choreDescription,
	                            choreLog.childUsername,
	                            choreLog.username,
	                            ChoreCategories.choreId,
	                            ChoreCategories.choreCategories,
	                            choreDescriptions.descriptionId,
	                            choreDescriptions.choreDescriptions,
	                            child.childId,
	                            child.childFirstname,
	                            users.userId,
	                            users.username
                                FROM
	                            ChoreDatabase.choreLog choreLog,
	                            ChoreDatabase.ChoreCategories ChoreCategories,
	                            ChoreDatabase.choreDescriptions choreDescriptions,
	                            ChoreDatabase.child child,
	                            ChoreDatabase.users users
                                WHERE 
                                choreLog.username = @userId AND
                                choreLog.choreCategory = ChoreCategories.choreId AND
	                            choreLog.choreDescription = choreDescriptions.descriptionId AND
	                            choreLog.childUsername = child.childId AND
	                            choreLog.username = users.userId AND
	                            child.childId = users.childs_id
	                            
	                            ORDER BY choreLog.id ASC;";

                    cmd.Parameters.AddWithValue("@userId", Login.userId);

                    using (MySqlDataReader rdr = cmd.ExecuteReader())
                    {
                        while (rdr.Read())
                        {
                            _childFirstname = rdr["childFirstname"].ToString() as string;
                            _choreCategory = rdr["choreCategories"].ToString() as string;
                            _choreDescription = rdr["choreDescriptions"].ToString() as string;
                            _id = rdr["id"].ToString() as string;

                           
                            Console.WriteLine("(ID: "+ _id + ")"+ _childFirstname + " completed a " + _choreCategory + " chore by doing: " + _choreDescription);

                            Console.WriteLine("= = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = =\n");
                            
                        }
                    }
                    try
                    {
                        
                        cmd.ExecuteNonQuery();
                    }
                    catch (MySqlException ex)
                    {
                        Console.WriteLine("Error: {0}", ex.ToString());
                    }
                    

                }
                conn1.Close();
            }
            
        }
    }
}
