﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;

namespace ChoreTracker
{
    class Program
    {

        static void Main(string[] args)
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine(MainTitle.Title());
            Console.ResetColor();
            Console.WriteLine("- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - \n\n");
            Login.TryLogin();
            Console.Clear();

            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine(MainTitle.Title());
            Console.ResetColor();

            pickMenu:
            MainMenu.Menu();

            string input = Console.ReadLine();
            int inputNum;
            int.TryParse(input, out inputNum);
            switch (inputNum)
            {
                case 1:
                    {
                        Console.Clear();
                        Console.WriteLine(MainTitle.Title());
                        UserDetails.DetailsBanner();
                        trackchore:
                        ChoreTrack.TrackChore();

                        Console.Clear();
                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.WriteLine(MainTitle.Title());
                        Console.ResetColor();

                        UserDetails.DetailsBanner();
                        Console.WriteLine("\n\n[1]Track Another Chore");
                        Console.WriteLine("[2] Main Menu");

                        input = Console.ReadLine();
                        int.TryParse(input, out inputNum);
                        switch (inputNum)
                        {
                            case 1:
                                {
                                    Console.Clear();
                                    Console.ForegroundColor = ConsoleColor.Green;
                                    Console.WriteLine(MainTitle.Title());
                                    Console.ResetColor();
                                    UserDetails.DetailsBanner();
                                    goto trackchore;
                                }

                            case 2:
                                {
                                    Console.Clear();
                                    Console.ForegroundColor = ConsoleColor.Green;
                                    Console.WriteLine(MainTitle.Title());
                                    Console.ResetColor();
                                    UserDetails.DetailsBanner();
                                    goto pickMenu;
                                }


                        }


                    }
                    break;
                case 2:
                    {
                        Console.Clear();
                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.WriteLine(MainTitle.Title());
                        Console.ResetColor();
                        UserDetails.DetailsBanner();
                        viewChoreLog:
                        ChoreLog.ViewLog();



                        Console.WriteLine("\n\n\n[1] Main Menu");
                        input = Console.ReadLine();
                        int.TryParse(input, out inputNum);
                        switch (inputNum)
                        {
                            case 1:
                                {
                                    Console.Clear();
                                    Console.ForegroundColor = ConsoleColor.Green;
                                    Console.WriteLine(MainTitle.Title());
                                    Console.ResetColor();
                                    UserDetails.DetailsBanner();
                                    goto pickMenu;
                                }

                        }
                    }
                    break;
                    
               
                case 3:
                    {
                        Console.Clear();
                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.WriteLine(MainTitle.Title());
                        Console.ResetColor();

                        getTheDetails:
                        AddChild.getDetails();

                        
                        AddChild.newChild();
                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.WriteLine(MainTitle.Title());
                        Console.ResetColor();


                        Console.WriteLine("[1] Add A New Child");
                        Console.WriteLine("[2] Main Menu");
                        input = Console.ReadLine();
                        int.TryParse(input, out inputNum);

                        switch (inputNum)
                        {
                            case 1:
                                {
                                    Console.Clear();
                                    
                                    goto getTheDetails;
                                    

                                }

                            case 2:
                                {
                                    Console.Clear();
                                    Console.ForegroundColor = ConsoleColor.Green;
                                    Console.WriteLine(MainTitle.Title());
                                    Console.ResetColor();
                                    UserDetails.DetailsBanner();
                                    goto pickMenu;

                                }

                        }
                    }
                    break;
                case 4:
                    {
                        Console.Clear();
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine(MainTitle.Title());
                        Console.ResetColor();
                        
                        
                        Login.LogOut();
                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.WriteLine(MainTitle.Title());
                        Console.ResetColor();
                        goto pickMenu;
                        
                    }
                case 5:
                    {
                        Environment.Exit(0);
                    }
                    break;
                    
            }
        }
    }
}
        
           


            
                    
  





