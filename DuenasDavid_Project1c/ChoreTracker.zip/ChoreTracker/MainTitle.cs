﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChoreTracker
{
  


   public class MainTitle
    {
        public static string Title()
        {
            Console.Title = "Timetracker";
            string title = @" 
 / __)( )_( )(  _  )(  _ \( ___)  (_  _)(  _ \  /__\  / __)( )/ )( ___)(  _ \
( (__  ) _ (  )(_)(  )   / )__)     )(   )   / /(__)\( (__  )  (  )__)  )   /
 \___)(_) (_)(_____)(_)\_)(____)   (__) (_)\_)(__)(__)\___)(_)\_)(____)(_)\_)";
            
            return title;
        }
    }
}
