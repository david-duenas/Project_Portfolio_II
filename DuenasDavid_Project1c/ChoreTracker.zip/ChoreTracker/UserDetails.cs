﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChoreTracker
{
    class UserDetails
    {
        public static void DetailsBanner()
        {
            Console.BackgroundColor = ConsoleColor.White;
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine("=====================================");
            Console.WriteLine("User ID: " + Login.userId);
            Console.WriteLine("Your Child's ID: " + Login.childs_id);
            Console.WriteLine("=====================================");

            Console.ResetColor();
        }
    }
}
