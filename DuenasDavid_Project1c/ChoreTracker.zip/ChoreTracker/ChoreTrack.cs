﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;

namespace ChoreTracker
{
    class ChoreTrack
    {

        public static string choreId;
        public static string choreCategories;
        public static string descriptionId;
        public static string choreDescriptions;


        public static void TrackChore()
        {
            Console.Clear();
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine(MainTitle.Title());
            Console.ResetColor();
            Console.WriteLine("Select a chore category from below: ");

            string cs = @"server=172.16.71.1;userid=davidduenas;password=pwd123;database=ChoreDatabase;port=8889";
            MySqlConnection conn;

            try
            {
                conn = new MySqlConnection(cs);
                conn.Open();
                MySqlDataReader rdr;

                string categoryStm = "SELECT choreId, choreCategories from choreCategories;";
                MySqlCommand categoryCmd = new MySqlCommand(categoryStm, conn);
                rdr = categoryCmd.ExecuteReader();

                while (rdr.Read())
                {
                    choreId = rdr["choreId"].ToString() as string;
                    choreCategories = rdr["choreCategories"].ToString() as string;

                    Console.WriteLine("[" + choreId + "]" + choreCategories);
                }
                conn.Close();
            }

            catch (Exception ex)
            {
                Console.WriteLine("Error: {0}", ex.ToString());
            }
            Console.WriteLine("");
            Console.WriteLine("Select a category option from above... EX: (1-5)");
            string categoryInput = Console.ReadLine();

            Console.Clear();

            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine(MainTitle.Title());
            Console.ResetColor();
            try
            {
                conn = new MySqlConnection(cs);
                conn.Open();
                MySqlDataReader rdr;
                string descriptionStm = "SELECT descriptionId, choreDescriptions FROM choreDescriptions;";
                MySqlCommand descriptionCmd = new MySqlCommand(descriptionStm, conn);
                rdr = descriptionCmd.ExecuteReader();

                while (rdr.Read())
                {
                    descriptionId = rdr["descriptionId"].ToString() as string;
                    choreDescriptions = rdr["choreDescriptions"].ToString() as string;

                    Console.WriteLine("[" + descriptionId + "]" + choreDescriptions);

                }



            }
            catch (Exception ex)
            {
                Console.WriteLine("Error: {0}", ex.ToString());
            }
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("\n\n\nSelect a chore from above... EX: (1-100)");
            Console.ResetColor();
            string descriptionInput = Console.ReadLine();

            Console.Clear();
            Console.WriteLine(MainTitle.Title());
            UserDetails.DetailsBanner();
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("Enter your child's user ID number...");
            Console.ResetColor();
            string childUserNameInput = Console.ReadLine();

            using (MySqlConnection conn1 = new MySqlConnection(cs))
            {
                using (MySqlCommand cmd = new MySqlCommand())
                {
                    cmd.Connection = conn1;
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.CommandText = @"INSERT INTO choreLog(choreCategory, choreDescription, childUsername, username)VALUES(@choreCategory, @choreDescription, @childUsername, @username)";

                    cmd.Parameters.AddWithValue("@choreCategory", categoryInput);
                    cmd.Parameters.AddWithValue("@choreDescription", descriptionInput);
                    cmd.Parameters.AddWithValue("@childUsername", childUserNameInput);
                    cmd.Parameters.AddWithValue("@username", Login.userId);

                    try
                    {
                        conn1.Open();
                        cmd.ExecuteNonQuery();
                    }
                    catch (MySqlException ex)
                    {
                        Console.WriteLine("Error: {0}", ex.ToString());
                    }
                }
                conn1.Close();
            }
            
            

        }

    }
}
